# CIS 1050 - Assignment 3

## Design

For my website I wanted to go for a clean modern design. lots of white space but not too much. 

I also wanted to incoroprate some simple fade in animations to add some intrigue to the pages when the user first sees them.

#### Color

As for colors, apart from the images I wanted to stick with white and dark grey. I didn't want black because that was a little bit too much contrast.

#### Font

As for fonts, I chose to use a blocky serif font for all of the headings and prominant links and for the main bodys of text to use a clean sans-serif font for easy readability.